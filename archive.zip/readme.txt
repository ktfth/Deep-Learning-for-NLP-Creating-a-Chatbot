﻿To comply with Twitter's Terms of Service, only tweet IDs are provided. To download the corresponding full tweets using your own Twitter API credentials.
The first line ("tweet_id start_pos end_pos named_entity_type") of the file is added to specify the above information regarding the annotations, so it is not part of the actual annotations.


